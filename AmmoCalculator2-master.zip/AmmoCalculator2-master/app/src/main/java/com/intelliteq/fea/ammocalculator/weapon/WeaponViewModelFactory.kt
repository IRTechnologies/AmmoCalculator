package com.intelliteq.fea.ammocalculator.weapon

class WeaponViewModelFactory {
}
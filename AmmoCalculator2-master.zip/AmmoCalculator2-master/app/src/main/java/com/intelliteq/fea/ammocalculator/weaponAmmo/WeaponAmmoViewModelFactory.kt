package com.intelliteq.fea.ammocalculator.weaponAmmo

class WeaponAmmoViewModelFactory {
}